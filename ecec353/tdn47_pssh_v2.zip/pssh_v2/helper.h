#ifndef _helper_h_
#define _helper_h_

void set_fg_pgid(pid_t pgid);
void safe_print(char* str);
int check_int(char* str);

#endif /* _helper_h */
