Tai Duc Nguyen - CS 435 - 05/31/2019

Homework 5:

1. Feature of program: Image rectification through the process of hough transform and homography
2. Name of entry point script: Homework_5.m // The image file is: test.jpg
3. Script above was compiled and ran on MATLAB r2018a
4. All answers, images and results are in the file "HW5.pdf"
