The pdf name is: 
    HW3.pdf
The MatLab Source file is: 
    Homework_3.m 
    backtrack.m
    bilinearInterpolation.m
    getOptimalSeam.m
The 2 images are: 
    boat.jpg
    fortress.jpg
The 2 videos are:
    boat.avi
    fortress.avi
