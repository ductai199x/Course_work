Tai Duc Nguyen - CS 435 - 05/16/2019

Homework 4:

1. Feature of program: Image feature extraction and classification
2. Name of entry point script: Homework_4.m // The data file is: images.dat
3. Script above was compiled and ran on MATLAB r2018a
4. All answers, images and results are in the file "HW4.pdf"

NOTE: THIS SUBMISSION DOES INCLUDE THE TRAIN&TEST in CarData folder
