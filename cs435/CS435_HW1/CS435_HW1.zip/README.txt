Tai Duc Nguyen - CS 435 - 04/10/2019

Homework 1:

1. Feature of program: Image analysis with point-pixel processing
2. Name of entry point script: Homework_1.m
3. Script above was compiled and ran on MATLAB r2018a
4. All answers, images and results are in the file "HW1.pdf"